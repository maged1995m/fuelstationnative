if(NOT TARGET react-native-worklets::worklets)
add_library(react-native-worklets::worklets SHARED IMPORTED)
set_target_properties(react-native-worklets::worklets PROPERTIES
    IMPORTED_LOCATION "/home/ubuntu/projects/fuel-station-native-01e61df1/source/node_modules/.pnpm/react-native-worklets@0.5.1_@babel+core@7.29.7_react-native@0.81.5_@babel+core@7.29.7_@types+_trc7tgs77m5tdbrh5auorqvjgq/node_modules/react-native-worklets/android/build/intermediates/cxx/RelWithDebInfo/50z2d5u5/obj/arm64-v8a/libworklets.so"
    INTERFACE_INCLUDE_DIRECTORIES "/home/ubuntu/projects/fuel-station-native-01e61df1/source/node_modules/.pnpm/react-native-worklets@0.5.1_@babel+core@7.29.7_react-native@0.81.5_@babel+core@7.29.7_@types+_trc7tgs77m5tdbrh5auorqvjgq/node_modules/react-native-worklets/android/build/prefab-headers/worklets"
    INTERFACE_LINK_LIBRARIES ""
)
endif()

