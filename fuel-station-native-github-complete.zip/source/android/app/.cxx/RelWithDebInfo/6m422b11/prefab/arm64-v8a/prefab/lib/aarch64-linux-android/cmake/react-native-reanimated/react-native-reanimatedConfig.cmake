if(NOT TARGET react-native-reanimated::reanimated)
add_library(react-native-reanimated::reanimated SHARED IMPORTED)
set_target_properties(react-native-reanimated::reanimated PROPERTIES
    IMPORTED_LOCATION "/home/ubuntu/projects/fuel-station-native-01e61df1/source/node_modules/react-native-reanimated/android/build/intermediates/cxx/RelWithDebInfo/3pg2ueoz/obj/arm64-v8a/libreanimated.so"
    INTERFACE_INCLUDE_DIRECTORIES "/home/ubuntu/projects/fuel-station-native-01e61df1/source/node_modules/react-native-reanimated/android/build/prefab-headers/reanimated"
    INTERFACE_LINK_LIBRARIES ""
)
endif()

